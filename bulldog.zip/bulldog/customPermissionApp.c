#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main(){
    printf("Please enter a valid username to use root privileges\n");
    printf("\tUsage: ./customPermissionApp <username>\n");

    system("sudo su root");
    char pass[100] = "SUPERultimatePASSWORDyouCANTget";
}
